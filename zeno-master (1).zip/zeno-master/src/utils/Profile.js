import React, { Fragment, useState, useEffect } from "react";
import { DropdownMenu, DropdownToggle, ListGroup, ListGroupItem } from 'reactstrap';
import { useAuth0 } from "../utils/react-auth0-spa";
import { AppHeaderDropdown } from '@coreui/react';

const Profile = () => {

  const { loading, user, getIdTokenClaims } = useAuth0();
  const [myuser, setmyuser] = useState ("user")
  const [role, setrole] = useState ("roles")
  
  if (loading || !user) {
    return <div>Loading...</div>;
  }

  // get the token from Auth0 throuhg async function
  async function getToken() {
    
    try {
      const token = await getIdTokenClaims();
      // store auth0 id as state myuser
      setmyuser (token.sub);
      //store token role as let first so it can be printed or shown
      let role = token[`https://${process.env.REACT_APP_ROLEURL}`];
      setrole (role);
      // console.log("Profile token:", token.__raw)
      console.log("roles url", process.env)
    } catch (error) {
      console.log(error);
    }
    }
  
  // useEffect is called after rendering (like componentDidMount), here I start the getToken function
  useEffect(() => {
    getToken();
  }, [] );

  return (
    
    <Fragment>

          <AppHeaderDropdown>

            <DropdownToggle nav>
              <img src={user.picture} className="img-avatar" alt="alt"/>
            </DropdownToggle>

            <DropdownMenu right style={{ right: 'auto', height: 'auto' }}>
              
                <ListGroup>
                    <ListGroupItem>Email: {user.email}</ListGroupItem>
                    <ListGroupItem>Role: {role}</ListGroupItem>
                    <ListGroupItem>{myuser}</ListGroupItem>
                    
                </ListGroup>

              {/* <code>{JSON.stringify(user, null, 2)}</code> */}

            </DropdownMenu>

          </AppHeaderDropdown>
          
    </Fragment>
  );
};

export default Profile;