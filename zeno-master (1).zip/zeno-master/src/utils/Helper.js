// helper getToken to get a token for API calls
import React, { useState } from "react";
import { useAuth0 } from "../utils/react-auth0-spa";

export async function getToken() {
    
    const { user, getIdTokenClaims } = useAuth0();
    const [myToken, setmyToken] = useState ("token")

    try {
      const token = await getIdTokenClaims();
      // store auth0 id as state myuser
      setmyToken (token.__raw);
  
    } catch (error) {
      console.log(error);
    }
return myToken;
}