import React from "react";
import { useAuth0 } from "./react-auth0-spa";
import { Container, Row } from 'reactstrap';

const AuthButton = () => {
  const { isAuthenticated, loginWithRedirect, logout } = useAuth0();

  return (
    <div>
      <Container>
        <Row>

          {!isAuthenticated && (
            <button className="btn First-btn" onClick={() => loginWithRedirect({})}>Log in</button>
          )}

          {isAuthenticated && <button className="btn First-btn" onClick={() => logout()}>Log out</button>}

        </Row>
      </Container>
    </div>
  );
};

export default AuthButton;