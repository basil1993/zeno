import React from "react";
import { Router, Route, Switch } from "react-router-dom";

// everything for authentication
import { useAuth0 } from "./utils/react-auth0-spa";
import Profile from "./utils/Profile";
import history from "./utils/history";
import PrivateRoute from "./utils/PrivateRoute";
import DefaultLayout from './containers/DefaultLayout'

import './App.scss';

import Welcome from './Welcome';

function App() {

  const { loading } = useAuth0();

  if (loading) {
    return <div className="animated fadeIn pt-3 text-center"><div className="sk-spinner sk-spinner-pulse"></div></div>;;
  }

  return (
    <div className="App">

      <Router history={history}>
        <div>
        {/* make defaultlayout a PrivateRoute to secure content */}
          <Switch>
            <Route exact path="/welcome" name="welcome" component={Welcome} />
            <PrivateRoute path="/" name="Home" component={DefaultLayout} />
            <PrivateRoute path="/profile" component={Profile} />
          </Switch>
          
          </div>
      </Router>
    </div>
  );
}

export default App;