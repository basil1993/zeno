import React, {Component} from 'react';
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap';

class ErrorModal  extends Component { 

  constructor(props) {
    super(props);
    this.state = {
      modal: false,
      error: ""
    };

    this.toggle = this.toggle.bind(this);
  }

  toggle() {
    this.setState({
      modal: !this.state.modal,
    });
  }


  render() {
    return (
      
        <Modal isOpen={this.state.modal} toggle={this.toggle} className='modal-sm'>
        
        <ModalHeader toggle={this.toggle}>Oops!</ModalHeader>
            <ModalBody>
            {this.state.error}
            </ModalBody>

        <ModalFooter>
        <Button color="primary" onClick={this.toggle}>Do Something</Button>{' '}
        <Button color="secondary" onClick={this.toggle}>Cancel</Button>
        </ModalFooter>
    
    </Modal>
    )
  }
}

export default ErrorModal;
