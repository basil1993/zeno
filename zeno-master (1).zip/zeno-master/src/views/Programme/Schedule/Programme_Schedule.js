import React, { Component } from 'react';

import Calendar from './Calendar'

class Programme_Schedule extends Component {

  render() {

    return (
     
      <Calendar />
    
    );
  }
}

export default Programme_Schedule;

