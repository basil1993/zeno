import React, { useState, useEffect } from "react";
import { Card, CardBody, CardHeader, Col, Row } from 'reactstrap';
import BigCalendar from 'react-big-calendar';
import moment from 'moment';
import Select from 'react-select';
import rp from "request-promise";
import { useAuth0 } from "../../../utils/react-auth0-spa";
import 'react-big-calendar/lib/css/react-big-calendar.css';

// Setup the localizer by providing the moment (or globalize) Object
// to the correct localizer.
BigCalendar.setLocalizer(
  BigCalendar.momentLocalizer(moment),
);

//this makes sure the react-select menu sits above the calendar date buttons
const selectStyles = { menu: styles => ({ ...styles, zIndex: 999 }) };

const Calendar = () => { 

  //Zeno user information
  const { getIdTokenClaims } = useAuth0();
  const [JWT, setJWT] = useState("")
  
  //states for programme user selection and schedule
  const [userList, setuserList] = useState([])
  const [selectedUser, setselectedUser] = useState("")
  const [schedule, setschedule] = useState([])


  // get the token from Auth0 throuhg async function
  async function getToken() {
    // console.log("1: Calendar fetching token")
    try {
      let token = await getIdTokenClaims();
      // console.log("token from getIdTokenClaims.__raw", token.__raw, token)
      setJWT(token.__raw);
      
    } catch (error) {
      console.log('token error:', error);
    }
    }


  //trigger getToken first after render.
  useEffect(() => {
    getToken();
  }, [] );


// handle selection of user and update the state
function handleChangeUser (selectedUser) {
  setselectedUser (selectedUser.value)
  // console.log("handlechange", selectedUser.value);
  getUserSchedule(JWT, selectedUser.value);
};


// fetch user List from Program Users API with userid and usertoken so they can be used in selection of individual
function getUserList (token) {

  console.log("2: getting user list with", token)

  // fetch data from marts API
  rp ({
    uri: `https://${process.env.REACT_APP_BASE_URL}/program/users`,
    json: true,
    headers : {
      "Authorization": token
    }}
  ) 
    .then(response => {
      let temp = new Set(response);
      let arraytemp = Array.from(temp)
      let map = arraytemp.map(user => { 
        return ({
        label: user, 
        value: user
          })
        })

      // console.log("map type after processing", map);
      setuserList(map);
      })
      .catch(error => 
        console.log('parsing failed', error)
        )
    }
    // .then(response => {
    // console.log("response from /program/users", response)

    // // Object.assign(target, response);
    // setuserList(response);
    // })
    // .catch(error => console.log('parsing failed', error))
    // }


// fetch individual schedule from API with userid, usertoken and the target individual so it can be used in calendar
function getUserSchedule (token, selectedUser) {

  // console.log("getting user schedule with", token, "for:", selectedUser);

  // fetch data from Schedule of User API
  rp({
    uri: `https://${process.env.REACT_APP_BASE_URL}/program/schedule?user=${selectedUser}`,
    json: true,
    headers: {
      "Authorization": token,
    },
  })
    .then((response) => {
      // console.log("response from schedule api", response);
      response.programs.map(event => {
        let oneschedule = event.schedule.map(entry => {
          return {
            title: entry.title,
            start: entry.target_time,
            end: entry.target_time
          }
          })
          setschedule(oneschedule);
          // console.log("entry:", oneschedule);    
          })
      }) 
      
    .catch((error) => console.log("parsing failed", error));
    }

    return (
      <Card>
        {/* if userdata is 0, then (&&) exectue UserTable with id and token */}
        {userList.length === 0 && JWT !== "" && getUserList(JWT)}
        {/* {console.log("3: in the render")} */}
        <CardHeader>
          <Row>
            <Col sm="8">
              <i className="icon-calendar"></i>{" "}
              <strong>Programme Schedule</strong>{" "}
              <div className="small text-muted">Select or search for a user</div>
            </Col>

            <Col sm="4">
            <Select
                    styles={selectStyles}
                    className="d-sm-down-none"
                    onChange={handleChangeUser}
                    options={userList}
                    //change the color of options (primary25) and the selected option (primary)
                    theme={theme => ({
                      ...theme,
                      colors: {
                        ...theme.colors,
                        // primary25: '#EF7B0B',
                        primary: '#EF7B0B',
                      },
                    })}
                    />
            </Col>
          </Row>
        </CardHeader>

        {/* Change the css file 'react-big-calendar.css' to change color of events and size of header */}
        <CardBody style={{ height: "40em" }}>
          <BigCalendar
            className="d-sm-down-none"
            events={schedule}
            views={["month", "agenda"]}
            defaultDate={schedule[0]}
            defaultView="month"
            toolbar={true}
            selectable={false}
          />
        
        </CardBody>
      </Card>
      
    );
    }


export default Calendar;

// change this in react-big-calender css file to make events unclickable
// .rbc-date-cell > a{
//   pointer-events: none;
// }

//change this in react-big-calendar css file to make the select sit above the date buttons
// .rbc-slot-selection {
//   z-index: 10; <----- set to 1
//   position: absolute;
//   background-color: rgba(0, 0, 0, 0.5);
//   color: white;
//   font-size: 75%;
//   width: 100%;
//   padding: 3px;
// }

// change this in react-big-calender css file to change colour of events.
// .rbc-event {
//   padding: 2px 5px;
//   background-color: #3174ad;