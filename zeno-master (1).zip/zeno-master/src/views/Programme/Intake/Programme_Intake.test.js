import React from 'react';
import ReactDOM from 'react-dom';
import Programme_Intake from './Intake';
import { shallow } from 'enzyme'


it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Programme_Intake />, div);
  ReactDOM.unmountComponentAtNode(div);
});

it('renders without crashing', () => {
  shallow(<Programme_Intake />);
});
