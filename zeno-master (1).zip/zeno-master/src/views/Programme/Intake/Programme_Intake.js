import React from 'react';

import data from '../Schedule/ExampleList.json';

const Programme_Intake = () => { 

console.log(data);

  let sander = new Set(data)
  
  let arraysander = Array.from(sander)
  arraysander.map(user => {
    return ({
      label: user,
      value: user
    })
  })
  
  console.log("Set", sander)
  console.log("Mapped", arraysander)
  
  return (
  
      <div className="animated fadeIn">

      This will show answers to the intake questionnaire from Typeform after selecting a participant from list.

      </div>

    );
  }


export default Programme_Intake;