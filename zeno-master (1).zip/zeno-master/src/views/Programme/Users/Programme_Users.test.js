import React from './node_modules/react';
import ReactDOM from './node_modules/react-dom';
import Programme_Users from './Users';
import { shallow } from './node_modules/enzyme'


it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Programme_Users />, div);
  ReactDOM.unmountComponentAtNode(div);
});

it('renders without crashing', () => {
  shallow(<Programme_Users />);
});
