import React, { Component } from 'react';

import UserTable from './UserTable';

class Programme_Users extends Component {
  render() {
    return (
      <div className="animated fadeIn">

       <UserTable />

      </div>
    );
  }
}

export default Programme_Users;
