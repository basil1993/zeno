import React, { useState, useEffect } from 'react'
import {Card, CardHeader, CardBody, Badge, Row, Col, Button } from 'reactstrap'
import BootstrapTable from 'react-bootstrap-table-next'
import paginationFactory from 'react-bootstrap-table2-paginator'
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit'
import { CSVLink } from "react-csv";
import { useAuth0 } from "../../../utils/react-auth0-spa";
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css'
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css'
import 'react-bootstrap-table2-toolkit/dist/react-bootstrap-table2-toolkit.min.css'
import moment from 'moment'

// check the signup date in datafile and change format for readibility
function CheckDate(cell){
  if (!cell) {
    return " "
  }
  return moment(cell).format("DD/MM/YYYY")
}

// check last incoming data and return a warning badge depending on when last data came in
function CheckLastData(cell, row) {
  let then = moment.parseZone(cell)
      if (moment().diff(then, 'days') > 5) {
         return <Badge color="danger" pill>{moment(cell).format("DD/MM/YYYY")}</Badge>
      }
      if (moment().diff(then, 'days') > 2) {
           return <Badge color="warning" pill>{moment(cell).format("DD/MM/YYYY")}</Badge>
        }
      return <Badge color="success" pill>{moment(cell).format("DD/MM/YYYY")}</Badge>
  }


// check if cell has value, if not return empty space so it doesnt give errors
function CheckDaysAgo(cell) {
  if (!cell) {
    return " "
  }
  return moment(cell).fromNow()
}


// define table columns and their properties
  const columns = [{
        dataField: 'auth0',
        text: 'Auth0',
        sort: true
      }, 
      {
        dataField: 'enrolled',
        text: 'Enrolled',
        formatter: CheckDate,
        sort: true
      },
      {
        dataField: 'vire',
        text: 'Used Vire',
        formatter: CheckDaysAgo,
        sort: true
      },
      {
        dataField: 'luka',
        text: 'Luka',
        formatter: CheckLastData,
        sort: true
      },
      {
        dataField: 'fitbit',
        text: 'Fitbit',
        formatter: CheckLastData,
        sort: true
      },
      {
        dataField: 'nimbus',
        text: 'Nimbus',
        formatter: CheckLastData,
        sort: true
      },
      {
        dataField: 'do',
        text: "Do's",
        sort: true
      }
    ];

const { SearchBar, ClearSearchButton } = Search

  const UserTable = () => {

    //empty states for JWT token
    const { getIdTokenClaims} = useAuth0();
    const [JWT, setJWT] = useState ("token")

    //set an empty state for userdata to store API data
    const [userdata, setuserdata] = useState([])

    //set a hidden state is true for the download csv button
    const [hidden, setHidden] = useState(true);

    // get the token from Auth0 throuhg async function
    async function getToken() {
      try {
        let token = await getIdTokenClaims();
        // console.log("token from getIdTokenClaims.__raw", token.__raw, token)
        setJWT (token.__raw);
    
      } catch (error) {
        console.log('token error:', error);
      }
      }
    
    // useEffect is called after rendering, here I start the getToken function
    useEffect(() => {
      getToken();
    }, [] );

    //prepare CSV for download
    function downloaddata() {
      // console.log("download:", dataset);
      setuserdata(userdata => userdata);
      setHidden(false)
    }

    function getUserTable (token) {
      
      // console.log(userId, token)
      console.log("called getUserTable with userId", "token", token)
    
    // fetch data from marts API, map it through key 'user' and define the different properties I want to have for table
      fetch(`https://86bb4cae.ngrok.io/getUsertable?user=`,{
      // fetch(`https://6acc6141.au.ngrok.io/`,{
    
        mode: 'cors',
        credentials: 'omit',
        headers: new Headers({
            // "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "https://zeno.pt.eu.onmi.design",
            // "Access-Control-Request-Method": "GET",
            "Authorization": token
          })
        }
      )
      
      .then(response => response.json())
      .then(parsedJSON => parsedJSON.programs.map(user => (
        {
            auth0: `${user.user}`,
            enrolled: `${user.created_at}`,
            vire: `${user.last_vire_opened}`,
            luka: `${user.last_luka_update}`,
            fitbit: `${user.last_fitbit_update}`,
            nimbus: `${user.last_nimbus_update}`,
            do: `${user.dos_completed} c / ${user.dos_scheduled} s`,
        }
        )))
    // update the state of contacts after fetching the API
        .then (userdata => setuserdata(userdata))
    // console log an error message if it fails
        .catch (error => console.log('parsing failed', error))
        }

    return (

        <Card>
       
       {/* if userdata is 0, then (&&) exectue UserTable with id and token */}
        {/* {userdata.length === 0 && JWT !== "" && getUserTable(JWT)} */}

        <ToolkitProvider
              keyField="auth0"
              data={ [userdata] }
              columns={ columns }
              search={ { searchFormatted: true } }
            >

            {
              props => (
                <div>

            <CardHeader>
              <Row>
                  <Col sm="4">
                    <i className="icon-people">{' '}</i><strong>Programme Users</strong>{' '}
                    <div className="small text-muted">Search for a user</div>
                  </Col>

                  <Col sm="2"></Col>

                  <Col sm="1">
                    <ClearSearchButton className="btn First-btn float-right" { ...props.searchProps } /> 
                  </Col>

                  <Col sm="4">
                    <SearchBar className="float-right" placeholder="Search" { ...props.searchProps } />
                  </Col>

                  {/* this download button needs to be pressed 2x, once to prepare the dataset for download and then to download */}
                  <Col sm="1" className="d-none d-sm-inline-block">
                    {hidden === true && <Button onClick={downloaddata} outline className="float-right First-btn"><i className="icon-printer"></i></Button>}
                    {hidden === false && <CSVLink data={userdata} filename={"Programme_users.csv"}><i className="btn btn-primary icon-cloud-download float-right"></i></CSVLink>}
                  </Col>

                  </Row>
          
            </CardHeader>
          
            <CardBody> 

              <BootstrapTable
                { ...props.baseProps }
                keyField="auth0"
                data={userdata}
                columns={columns}
                hover
                bordered={ false }
                noDataIndication="Nothing to display"
                pagination={ paginationFactory() }
                bootstrap4
              />

            </CardBody>
            
        
              </div>
              )
            }
            </ToolkitProvider>
           
        </Card>
        );
      }
    

export default UserTable;