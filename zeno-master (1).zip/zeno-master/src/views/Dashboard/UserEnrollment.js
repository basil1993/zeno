import React, { Component } from 'react';
import { Line } from 'react-chartjs-2';
import { Button, Card, CardBody, CardHeader, Col, Row, } from 'reactstrap';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import moment from 'moment'
import { CSVLink } from "react-csv";
    

  // settings for the tooltip, colours, Axes etc.
  const mainChartOpts = {
    tooltips: {
      enabled: false,
      custom: CustomTooltips,
      intersect: true,
      mode: 'index',
      position: 'nearest',
      callbacks: {
        labelColor: function(tooltipItem, chart) {
          return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor }
        }
      }
    },
    maintainAspectRatio: false,
    legend: {
      display: true,
    },
    scales: {
      xAxes: [
        {
          gridLines: {
            drawOnChartArea: false,
          },
        }],
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            maxTicksLimit: 5,
            stepSize: Math.ceil(250 / 5),
            max: 250,
          },
        }],
    },
    elements: {
      point: {
        radius: 0,
        hitRadius: 10,
        hoverRadius: 4,
        hoverBorderWidth: 3,
      },
    },
  };


  class UserEnrollment extends Component {
  
    constructor(props){
      super(props);
      this.state = {
        download: {},
        hidden: true,
        mainChart: {}
      }
      // This binding is necessary to make `this` work in the callback
      this.downloaddata = this.downloaddata.bind(this);
    }
    
    downloaddata() {
      // console.log("download:", dataset);
      this.setState({
        hidden: false,
      })
    }

    // loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>
      render(){
      return (
        
        <div className="animated">
          
              <Card>
                
              <CardHeader>
                <Row>
                  
                    <Col sm="5">
                        <i className="icon-user-following"></i>{' '}<strong>User Enrollment</strong>
                        <div className="small text-muted">From {moment().subtract(29, 'days').format("DD MMMM YYYY")} until {moment().format("DD MMMM YYYY")}</div>
                    </Col>
                
                    {/* this download button needs to be pressed 2x, once to update the dataset for download and then to download */}
                    <Col sm="7" className="d-none d-sm-inline-block">
                        {this.state.hidden === true  && <Button onClick={this.downloaddata} outline className="float-right First-btn"><i className="icon-printer"></i></Button>}
                        {this.state.hidden === false && <CSVLink data={this.props.download} filename={"User_Enrollment.csv"}><i className="btn btn-primary icon-cloud-download float-right"></i></CSVLink>}
                        
                    </Col>

                </Row>
                </CardHeader>

                <CardBody>
                  <div className="chart-wrapper" style={{ height: 300 + 'px', marginTop: 40 + 'px' }}>
                    {/* {console.log("dataset Labels:", Label, "dataset Enrolled", Enrolled, "dataset Completed", Completed)}  */}
                    <Line data={this.props.mainChart} options={mainChartOpts} height={300} />
                  </div>
                </CardBody>

              </Card>
 
        </div>
      );
      }}
  
  export default UserEnrollment;
  
// // take the correct numbers from the dataset state which is filled by API, 2 ways or writing this
// var Enrolled = dataset.map(e => {
//   return e.datasetEnrolled;
// });
// var Completed = dataset.map(function (e) {
//   return e.datasetCompleted;
// });
// var Label = dataset.map(function (e) {
//   return e.datasetLabel;
// });