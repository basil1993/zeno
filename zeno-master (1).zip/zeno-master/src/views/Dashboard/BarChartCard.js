import React, { Component } from 'react';
import { Bar } from 'react-chartjs-2';
import {Card, CardBody, Col} from 'reactstrap';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';


const Options = {
    tooltips: {
        enabled: false,
        custom: CustomTooltips
      },
      maintainAspectRatio: false,
      legend: {
        display: false,
      },
      scales: {
        xAxes: [
          {
            display: false,
            barPercentage: 0.6,
          }],
        yAxes: [
          {
            display: false,
          }],
      },
  }

  class CarChartCard extends Component {

    constructor(props) {
      super(props);
      this.state = {
        data: {},
        cardstyle: {},
        title: [" "],
        topvalue: [" "]
    }
  }

    render() {
        return (
         
          <Col xs="12" sm="6" lg="3">
            <Card className={this.props.cardstyle}>
              
              <CardBody className="pb-0">
                <div className="text-value">{this.props.topvalue}</div>
                <div>{this.props.title}</div>
              </CardBody>

              <div className="chart-wrapper mt-3" style={{ height: '70px' }}>
                <Bar data={this.props.data} options={Options} height={70}/>
              </div>
            
            </Card>
          </Col>
        
    );
  }
}

export default CarChartCard;