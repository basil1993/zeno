import React, { useState, useEffect } from 'react';
import { Row, Col, Card, CardBody, CardHeader } from 'reactstrap';
import { useAuth0 } from "../../utils/react-auth0-spa";
import LineChartCard from './LineChartCard';
import BarChartCard from './BarChartCard';
import UserEnrollment from './UserEnrollment';
import rp from "request-promise";
import moment from 'moment'

// import data from '../Do/Overview/Status of Program.json';
// //sort response by date
// data.sort(function (a, b) {
//   return new Date(a.date) - new Date(b.date);
// })

// var Dates = dataset.map(e => {return moment(e.date).format("YYYY-MM-DD");});
// var Enrolled = dataset.map(e => { return e.enrolled_users; });
// var Scheduled = dataset.map(e => { return e.scheduled_messages; });
// var Sent = dataset.map(e => { return e.sent_messages; });
// var Completed = dataset.map(e => { return e.completed_messages; });

// let TotalEnrolled = dataset.reduce((acc, el) => acc + (el.enrolled_users !== 0 && el.enrolled_users), 0);
// let TotalScheduled = dataset.reduce((acc, el) => acc + (el.scheduled_messages !== 0 && el.scheduled_messages), 0);
// let TotalSent = dataset.reduce((acc, el) => acc + (el.sent_messages !== 0 && el.sent_messages), 0);
// let TotalCompleted = dataset.reduce((acc, el) => acc + (el.completed_messages !== 0 && el.completed_messages), 0);

const Dashboard = () => { 

  //set token states with Hooks
  const { getIdTokenClaims } = useAuth0();
  const [JWT, setJWT] = useState("")

  //set emtpy state for dataset from API
  const [dataset, setdataset] = useState([]);


  // get the token from Auth0 throuhg async function
  async function getToken() {
    // console.log("1: Dashboard fetching token")
    try {
      let token = await getIdTokenClaims();
      setJWT(token.__raw);
    } catch (error) {
      console.log("token failed", error);
    }
  }


  // useEffect is called after rendering, here I start the getToken function
  useEffect(() => {
    getToken();
  }, []);


  function getData(token) {
    // console.log("2: Dashboard fetching data")
    // fetch data from Status of Program API
    rp({
      uri: `https://${process.env.REACT_APP_BASE_URL}/program/status?days=29`,
      json: true,
      headers: {
        "Authorization": token,
      },
    })
      .then((response) => {
        // console.log("response from schedule api", response);
        let temp = response.map(msg => {
          return {
            date: `${msg.date}`,
            enrolled: msg.enrolled_users, 
            scheduled: msg.scheduled_messages, 
            sent: msg.sent_messages,
            completed: msg.completed_messages
          }
        })
        //sort response by date
        temp.sort(function (a, b) {
          return new Date(a.date) - new Date(b.date);
        })
        // update the state of contacts after fetching the API
        setdataset(temp)
        // console.log("Adherence dataset:", temp)
        
      })
      // console log an error message if it fails
      .catch(error => console.log('parsing failed', error))
  }

  var Dates = dataset.map(e => { return moment(e.date).format("YYYY-MM-DD"); });
  var Enrolled = dataset.map(e => { return e.enrolled; });
  var Scheduled = dataset.map(e => { return e.scheduled; });
  var Sent = dataset.map(e => { return e.sent; });
  var Completed = dataset.map(e => { return e.completed; });

  var TotalEnrolled = dataset.reduce((acc, el) => acc + (el.enrolled !== 0 && el.enrolled), 0);
  var TotalScheduled = dataset.reduce((acc, el) => acc + (el.scheduled !== 0 && el.scheduled), 0);
  var TotalSent = dataset.reduce((acc, el) => acc + (el.sent !== 0 && el.sent), 0);
  var TotalCompleted = dataset.reduce((acc, el) => acc + (el.completed !== 0 && el.completed), 0);

  // Card Chart 1
  const cardChartData1 = {
    labels: Dates.slice(23),
    datasets: [
      {
        label: 'Users enrolled',
        backgroundColor: 'rgba(255,255,255,.2)',
        borderColor: 'rgba(255,255,255,.55)',
        data: Enrolled.slice(23),
      },
    ],
  };

  // Card Chart 2
  const cardChartData2 = {
    labels: Dates.slice(23),
    datasets: [
      {
        label: "Do's scheduled",
        backgroundColor: 'rgba(255,255,255,.2)',
        borderColor: 'rgba(255,255,255,.55)',
        data: Scheduled.slice(23),
      },
    ],
  };

  // Card Chart 3
  const cardChartData3 = {
    labels: Dates.slice(23),
    datasets: [
      {
        label: "Do's sent",
        backgroundColor: 'rgba(255,255,255,.2)',
        borderColor: 'rgba(255,255,255,.55)',
        data: Sent.slice(23),
      },
    ],
  };

  // Card Chart 4
  const cardChartData4 = {
    labels: Dates.slice(23),
    datasets: [
      {
        label: "Do's completed",
        backgroundColor: 'rgba(255,255,255,.2)',
        borderColor: 'transparent',
        data: Completed.slice(23),
      },
    ],
  };

  // User Enrollment
  const mainChartData = {
    labels: Dates,
    datasets: [
      {
        label: 'Users Enrolled',
        backgroundColor: 'transparent',
        borderColor: '#EF7B0B',
        pointHoverBackgroundColor: '#fff',
        borderWidth: 2,
        data: Completed
      },
      {
        label: 'Users Completed',
        backgroundColor: 'transparent',
        borderColor: '#878787',
        pointHoverBackgroundColor: '#fff',
        borderWidth: 2,
        data: Enrolled
      },
      // {
      //   label: 'Expected Enrollment',
      //   backgroundColor: 'transparent',
      //   borderColor: '#878787',
      //   pointHoverBackgroundColor: '#fff',
      //   borderWidth: 1,
      //   borderDash: [8, 5],
      //   data: data3,
      // },
    ],
  };


  // loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>  
    return (

      <div className="animated fadeIn">

        <Row>
          <LineChartCard
            title={"Users enrolled"}
            data={cardChartData1}
            cardstyle={"text-white First"}
            topvalue={TotalEnrolled}
          />

          <BarChartCard
            title={"Do's scheduled"}
            data={cardChartData2}
            cardstyle={"text-white Second"}
            // title={cardChartData2.labels.slice(-1)[0]}
            topvalue={TotalScheduled}
          />

          <LineChartCard
            title={"Do's sent"}
            data={cardChartData3}
            cardstyle={"text-white Third"}
            topvalue={TotalSent}
          />

          <BarChartCard
            title={"Do's completed"}
            data={cardChartData4}
            cardstyle={"text-white Second"}
            // title={cardChartData4.labels.slice(-1)[0]}
            topvalue={TotalCompleted}
          />
        </Row>

        <UserEnrollment mainChart={mainChartData} download={dataset}/>

        <Card>

          {/* if  is 0, then execute function getDoStatistics */}
          {dataset.length === 0 && JWT !== "" && getData(JWT)}

          <CardHeader>
            <i className="icon-chemistry"></i>
            <strong>Programme Information</strong>{" "}
            <div className="small text-muted"></div>
          </CardHeader>

          <CardBody>
            <Row>
              <Col>
                <Card>
                  <CardBody>
                    <div className="h3 text-muted text-right mb-2">
                      <i className="icon-info First-icon"></i>
                    </div>
                    <div className="h5 mb-0">{process.env.REACT_APP_PROJECT_TITLE}</div>
                    <small className="text-muted text-uppercase font-weight-bold">
                      Title
                    </small>
                  </CardBody>
                </Card>
              </Col>

              <Col>
                <Card>
                  <CardBody>
                    <div className="h3 text-muted text-right mb-2">
                      <i className="icon-hourglass First-icon"></i>
                    </div>
                    <div className="h5 mb-0">{process.env.REACT_APP_PROJECT_DURATION}</div>
                    <small className="text-muted text-uppercase font-weight-bold">
                      Duration
                    </small>
                  </CardBody>
                </Card>
              </Col>

              <Col>
                <Card>
                  <CardBody>
                    <div className="h3 text-muted text-right mb-2">
                      <i className="icon-calendar First-icon"></i>
                    </div>
                    <div className="h5 mb-0">{process.env.REACT_APP_PROJECT_STARTS}</div>
                    <small className="text-muted text-uppercase font-weight-bold">
                      Starts
                    </small>
                  </CardBody>
                </Card>
              </Col>

              <Col>
                <Card>
                  <CardBody>
                    <div className="h3 text-muted text-right mb-2">
                      <i className="icon-calendar First-icon"></i>
                    </div>
                    <div className="h5 mb-0">{process.env.REACT_APP_PROJECT_ENDS}</div>
                    <small className="text-muted text-uppercase font-weight-bold">
                      Ends
                    </small>
                  </CardBody>
                </Card>
              </Col>

              <Col>
                <Card>
                  <CardBody>
                    <div className="h3 text-muted text-right mb-2">
                      <i className="icon-people First-icon"></i>
                    </div>
                    <div className="h5 mb-0">{process.env.REACT_APP_PROJECT_AMOUNTUSERS}</div>
                    <small className="text-muted text-uppercase font-weight-bold">
                      users
                    </small>
                  </CardBody>
                </Card>
              </Col>
            </Row>

            <p>
              <strong>Description:</strong>
              <br></br>
              <br></br>A Do-omics programme to help you reach a healthy weight.
              Of course, weight management means eating sensibly and exercising
              regularly. But it's also about tackling the small every day habits
              that may have been making it hard for you to lose weight. This
              programme tackles those habits directly in an enjoyable,
              personalised programme. It will bring you health and vitality in
              small, fun, easy-to-do steps.{" "}
            </p>
          </CardBody>
        </Card>


        {/* <p>last value of an array: {cardChartData4.labels.slice(-1)[0]}</p>
        <p>first value of an array: {cardChartData4.labels[0]}</p>
        <p>the whole array: {cardChartData4.labels}</p>

        <p> nested data array: 
        {cardChartData4.datasets.map(i => {
          return `${i.data}`
            })} 
        </p>

        <p> last number in nested data array: 
        {cardChartData4.datasets.map(i => {
          return `${i.data.slice(-1)[0]}`
            })} 
        </p> */}
      </div>
    );
  }


export default Dashboard;
