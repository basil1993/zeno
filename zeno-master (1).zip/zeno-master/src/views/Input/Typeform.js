import React, { Component } from 'react';

class Typeform extends Component {
  render() {
    return (
      <div className="animated fadeIn">
        Hello Typeform!
      </div>
    );
  }
}

export default Typeform;
