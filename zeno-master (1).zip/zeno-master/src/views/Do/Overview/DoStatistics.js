import React, { useState, useEffect} from 'react';
import {Card, CardHeader, CardBody, Row, Col, Button} from 'reactstrap';
import { useAuth0 } from "../../../utils/react-auth0-spa";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import rp from "request-promise";
import { CSVLink } from "react-csv";
import moment from 'moment'

// this function checks the value of the cell, if it says avs in JSON it shows data-driven in the cell
function format (cell){
  if (cell === "avs") {
      return "data-driven";
        }
  return (cell)
}

// define table columns and their properties
const columns = [{
  dataField: 'category',
  text: 'Category',
  formatter: format,
  sort: true,
},
{
  dataField: "title",
  text: 'Title',
  sort: true,
  // headerStyle: { width: '15%' }
},
{
  dataField: "sent",
  text: 'Sent',
  sort: true,
  headerAlign: 'center',
  align: 'center'
},
{
  dataField: "completed",
  text: 'Completed',
  sort: true,
  headerAlign: 'center',
  align: 'center'
},
{
  dataField: "sum",
  text: 'Sum',
  sort: true,
  headerAlign: 'center',
  align: 'center'
},
{
  dataField: "high",
  text: 'High',
  sort: true,
  headerAlign: 'center',
  align: 'center',
  headerStyle: { width: '10%' },
  headerFormatter: formatter
},
  {
    dataField: "medium",
    text: 'Neutral',
    sort: true,
    headerAlign: 'center',
    align: 'center',
    headerStyle: { width: '10%' },
    headerFormatter: formatter
  },
  {
    dataField: "low",
    text: 'Low',
    sort: true,
    headerAlign: 'center',
    align: 'center',
    headerStyle: { width: '10%' },
    headerFormatter: formatter
  }
  
];

function formatter (cell){ 
  if (cell.text === 'High'){
    return <i className="fa fa-smile-o fa-lg" />;
  }
  if (cell.text === "Neutral") {
      return <i className="fa fa-meh-o fa-lg" />
    }
  if (cell.text === "Low") {
    return <i className="fa fa-frown-o fa-lg" />
  }
  return "??";
}

const DoStatistics = () => { 

  //set token states with Hooks
  const { getIdTokenClaims } = useAuth0();
  const [JWT, setJWT] = useState("");

  //set empty state of userdata
  const [userdata, setuserdata] = useState([])

  //set a hidden state is true for the download csv button
  const [hidden, setHidden] = useState(true);


  // get the token from Auth0 throuhg async function
  async function getToken() {
    // console.log("1: DoStatistics fetching token")
    try {
      let token = await getIdTokenClaims();
      // console.log("token from getIdTokenClaims.__raw", token.__raw);
      setJWT(token.__raw);

    } catch (error) {
      console.log(error);
    }
    }


  function getDoStatistics (token) {
    // console.log("getting user schedule with", token, "for:", selectedUser);

    // fetch data from marts API
    rp({
      uri: `https://${process.env.REACT_APP_BASE_URL}/messages/summary`,
      json: true,
      headers: {
        "Authorization": token,
      },
    })
      .then((response) => {
        // console.log("response from schedule api", response);
        let temp = response.messages.map(msg => {
          return {
            uid: msg.uid,
            category: msg.category,
            title: msg["title@en"],
            sent: msg.times_scheduled,
            completed: msg.times_completed ? msg.times_completed : 0,
            sum: msg.rated_by ? msg.rated_by.reduce((acc, el) => acc + (el.rating !== 0 && el.rating), 0) : 0,
            low: msg.rated_by ? msg.rated_by.reduce((acc, el) => acc + (el.rating === 0), 0) : 0,
            medium: msg.rated_by ? msg.rated_by.reduce((acc, el) => acc + (el.rating === 1), 0) : 0,
            high: msg.rated_by ? msg.rated_by.reduce((acc, el) => acc + (el.rating === 2), 0) : 0,
        }
      })
    // update the state of contacts after fetching the API
        setuserdata(temp)
        // console.log("userdata:", temp)
    })
    // console log an error message if it fails
      .catch (error => console.log('parsing failed', error))
      }


    //trigger getToken first after render.
    useEffect(() => {
      getToken();
    }, [] );


    //prepare CSV for download
    function downloaddata () {
      // console.log("download:", dataset);
      setuserdata (userdata => userdata);
      setHidden(false)
    }

    
    return (
      <div className="animated">
        <Card>
          
          {/* if  is 0, then execute function getDoStatistics */}
          {userdata.length === 0 && JWT !== "" && getDoStatistics(JWT)}
          
          <CardHeader>
            <Row>

              <Col sm="11">
                <i className="icon-trophy"></i>{' '}<strong>Do Statistics</strong>
                <div className="small text-muted">From (Enter start date!) until {moment().format("DD MMMM YYYY")}</div>
              </Col>

              {/* this download button needs to be pressed 2x, once to update the dataset for download and then to download */}
              <Col sm="1" className="d-none d-sm-inline-block">
                {hidden === true && <Button onClick={downloaddata} outline className="float-right First-btn"><i className="icon-printer"></i></Button>}
                {hidden === false  && <CSVLink data={userdata} filename={"DoStatistics.csv"}><i className="btn btn-primary icon-cloud-download float-right"></i></CSVLink>}
              </Col>

            </Row>

          </CardHeader>

          <CardBody> 
            
            <BootstrapTable
              keyField='uid' 
              data={userdata} 
              columns={columns} 
              hover 
              bordered={ false }
              noDataIndication="No data available"
              pagination={ paginationFactory() }
              striped
              bootstrap4                
              />

          </CardBody>
        </Card>
      
      </div>
    );
  }
    
              
export default DoStatistics;

// add this to the css file for long text
// .doTable{
//   white-space: nowrap;
//   text-overflow: ellipsis;
//   overflow: hidden;
// }