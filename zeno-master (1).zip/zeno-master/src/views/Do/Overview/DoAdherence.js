import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {Button, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { useAuth0 } from "../../../utils/react-auth0-spa";
import moment from 'moment'
import { CSVLink } from "react-csv";
import rp from "request-promise";


  const DoAdherence = () => {  

  //set token states with Hooks
    const { getIdTokenClaims} = useAuth0();
    const [JWT, setJWT] = useState ("")
  
    //set a hidden state is true for the download csv button
    const [hidden, setHidden] = useState(true);

    //set emtpy state for dataset from API
    const [dataset, setdataset] = useState([]);

    
    // get the token from Auth0 throuhg async function
    async function getToken() {
      // console.log("1: DoAdherence fetching token")
      try {
        let token = await getIdTokenClaims();
        setJWT (token.__raw);
    
      } catch (error) {
        console.log("token failed", error);
      }
      }
    
    
    // useEffect is called after rendering, here I start the getToken function
    useEffect(() => {
      getToken();
    }, []);


    //prepare CSV for download
    function downloaddata() {
      // console.log("download:", dataset);
      setdataset(dataset => dataset);
      setHidden(false)
    }


    function getDoAdherence (token) {
      // console.log("2: DoAdherence fetching data")
      // fetch data from marts API
      rp({
        uri: `https://${process.env.REACT_APP_BASE_URL}/program/status?days=29`,
        json: true,
        headers: {
          "Authorization": token,
        },
      })
        .then((response) => {
          // console.log("response from schedule api", response);
          let temp = response.map(msg => {
            return {
              date: `${msg.date}`,
              sent: `${msg.sent_messages}`,
              completed: `${msg.completed_messages}`
            }
          })
          //sort response by date
          temp.sort(function(a,b){
            return new Date(a.date) - new Date(b.date);
          })
          // update the state of contacts after fetching the API
          setdataset(temp)
          //store sorted temp in localstorage as string
          // localStorage.setItem('mylocalstorage', JSON.stringify(temp)) 
          // console.log("Adherence dataset:", temp)
        })
        // console log an error message if it fails
        .catch(error => console.log('parsing failed', error))
    }

    
    // take the correct numbers from the dataset state which is filled by API and store in variable, the graph cannot read state object
    var Sent = dataset.map(e => {
      return e.sent;
    });
    var Completed = dataset.map(function (e) {
      return e.completed;
    });
    var Label = dataset.map(function (e) {
        return moment(e.date).format('YYYY-MM-DD');
      });

    // var Label = dataset.sort((a, b) => new Date(a.date) - new Date(b.date))
    //   .map(function (e) {
    //     return e.date;
    //   });

    //define the graph, what data goes in, how is it visualised, what are the labels.
    const mainChart = {
      labels: Label,
      datasets: [
        {
          label: "Do's Completed",
          backgroundColor: 'transparent',
          borderColor: '#EF7B0B',
          pointHoverBackgroundColor: '#fff',
          borderWidth: 2,
          data: Completed
        },
        {
          label: "Do's Sent",
          backgroundColor: 'transparent',
          borderColor: '#878787',
          pointHoverBackgroundColor: '#fff',
          borderWidth: 2,
          data: Sent
        }
      ]
    };

    const mainChartOpts = {
      tooltips: {
        enabled: false,
        custom: CustomTooltips,
        intersect: true,
        mode: 'index',
        position: 'nearest',
        callbacks: {
          labelColor: function (tooltipItem, chart) {
            return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor }
          }
        }
      },
      maintainAspectRatio: false,
      legend: {
        display: true,
      },
      scales: {
        xAxes: [
          {
            gridLines: {
              drawOnChartArea: false,
            },
          }],
        yAxes: [
          {
            ticks: {
              beginAtZero: true,
              maxTicksLimit: 5,
              stepSize: Math.ceil(500 / 5),
              max: 500,
            },
          }],
      },
      elements: {
        point: {
          radius: 0,
          hitRadius: 10,
          hoverRadius: 4,
          hoverBorderWidth: 3,
        },
      },
    };

    
      return (
        <div className="animated">
          
              <Card>

                {/* if  is 0, then execute function getDoStatistics */}
                {dataset.length === 0 && JWT !== "" && getDoAdherence(JWT)}

              <CardHeader>
                <Row>
                  <Col sm="11">
                      <i className="icon-directions"></i>{' '}<strong>Do Adherence</strong>
                      <div className="small text-muted">From {moment().subtract(29, 'days').format("DD MMMM YYYY")} until {moment().format("DD MMMM YYYY")}</div>
                  </Col>

                  <Col sm="1" className="d-none d-sm-inline-block">
                    {hidden === true  && <Button onClick={downloaddata} outline className="float-right First-btn"><i className="icon-printer"></i></Button>}
                    {hidden === false && <CSVLink data={dataset} filename={"DoAdherence.csv"}><i className="btn btn-primary icon-cloud-download float-right"></i></CSVLink>}
                  </Col>

                </Row>
              </CardHeader>

                <CardBody>
                  <div className="chart-wrapper" style={{ height: 300 + 'px', marginTop: 40 + 'px' }}>
                    <Line data={mainChart} options={mainChartOpts} height={300} />

                    {/* {console.log("3: dataset Labels:", Label, "dataset Sent", Sent, "dataset Completed", Completed, "LocalData=", localStorage.getItem('mylocalstorage'))}  */}
                    
                  </div>
                </CardBody>

              </Card>
 
        </div>
      );
    }
  
  export default DoAdherence;
  