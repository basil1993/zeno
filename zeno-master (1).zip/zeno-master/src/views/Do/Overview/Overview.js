import React, { Component } from 'react';

import DoStatistics from './DoStatistics'
import DoAdherence from './DoAdherence'

class Do_Overview extends Component {

  render() {

    return (

        <div className="animated fadeIn">

          <DoStatistics />
          <DoAdherence/>

        </div>

      )}

  }


export default Do_Overview;
