import React, { Component } from 'react';
// import { Redirect } from "react-router-dom";
// import {Row} from 'reactstrap';

import DoTable from './DoTable';
// import SearchForm from './SearchForm';
// import ChangeForm from './ChangeForm';

class Repository extends Component {

  render() {
    return (

      <div className="animated fadeIn">

        <DoTable />

      </div>
    );
  }
}

export default Repository;