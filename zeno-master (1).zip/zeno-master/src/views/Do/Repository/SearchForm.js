import React, { Component } from 'react';
import {Button, Card, Form, CardBody, CardFooter, CardHeader, Col, FormGroup, Input, Label, Row,} from 'reactstrap';
import Select from 'react-select';

// import list of Labels from local file
import states from './data/states';

// define list of options within local file 
const Labels = states.US;

// define list of options for Type of Do selection
const TypesofDos = [
  { value: ' ', label: 'Any' },
  { value: 'starter', label: 'Starter' },
  { value: 'general', label: 'General' },
  { value: 'personalised', label: 'Personalised' },
  { value: 'expander', label: 'Expander' },
  { value: 'avs', label: 'Data Driven' },
];

// define list of available languages
const languages = [
  { value: 'en', label: 'English' },
  { value: 'nl', label: 'Nederlands' },
];

class SearchForm extends Component {

  // deal with selections of form
  constructor(props) {
    super(props);
    this.state = {
      selectedLabel: [],
      selectedDoType: TypesofDos[0],
      doTitle: ' ',
      doBody: ' ',
      SelectedLanguage: languages[0]
    };

    this.handleChangeTitle = this.handleChangeTitle.bind(this);
    this.handleChangeBody = this.handleChangeBody.bind(this);
    this.saveChanges = this.saveChanges.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // handle multiple selections of labels
  saveChanges(selectedLabel) {
    this.setState({ selectedLabel });
  }

  // handle entering a Do title, turn value from field into the title prop
  handleChangeTitle(event) {
    this.setState({doTitle: event.target.value});
  }

  // handle entering a Do body, turn value from field into the body prop
  handleChangeBody(event) {
    this.setState({doBody: event.target.value});
  }

  // handle selection of Do type and update the state
  handleChangeType = selectedDoType => {
    this.setState({ selectedDoType });
  };

  // handle language selection and update the state
  handleChangeLanguage = SelectedLanguage => {
    this.setState({ SelectedLanguage });
  }; 

  // handle submit button, take values from different fields and log in console
  handleSubmit(event) {
    console.log('Search Form submitted: ', 'category:', this.state.selectedDoType.value, 'title@', this.state.SelectedLanguage.value,':', this.state.doTitle,'body@', this.state.SelectedLanguage.value,':', this.state.doBody, 'labels:', this.state.selectedLabel);
    event.preventDefault();
  }

  render() {

    // these 5 console.logs are not necessary, only if I want to print the selection in console as it happens before submitting
    const { selectedLabel } = this.state;
    console.log(`Search Form Labels selected:`, selectedLabel);

    const { selectedDoType } = this.state;
    console.log(`Search Form Do Type selected:`, selectedDoType);

    const { SelectedLanguage } = this.state;
    console.log(`Search Form Language selected:`, SelectedLanguage);

    const { doTitle } = this.state;
    console.log(`Search title:`, doTitle);

    const { doBody } = this.state;
    console.log(`Search body:`, doBody);

    return (
  
      <Col xs="12" lg="6">
            <Card>
              <Form ref="searchform" onSubmit={this.handleSubmit}>
              
              <CardHeader>
              <i className="icon-magnifier"></i><strong>Search Do's</strong>{' '}
              </CardHeader>
              <CardBody>
              
                <Row>
                  <Col xs="8">
                    <FormGroup>
                      <Label htmlFor="dotitle">Title</Label>
                      <Input type="text" placeholder="LETS GO DAY" value={this.state.value} onChange={this.handleChangeTitle}/>
                    </FormGroup>
                  </Col>

                  <Col xs="4">
                    <FormGroup>
                      <Label htmlFor="language">Language</Label>
                      <Select
                        value={SelectedLanguage}
                        onChange={this.handleChangeLanguage}
                        options={languages}
                        />
                    </FormGroup>
                  </Col>
                </Row>

                <Row>
                <Col xs="12">
                <FormGroup>
                      <Label htmlFor="label">Labels</Label>
                      <Select
                        // name="form-field-name2"
                        value={selectedLabel}
                        closeMenuOnSelect={false}
                        // defaultValue={[Labels[0], Labels[1]]}
                        options={Labels}
                        onChange={this.saveChanges}
                        isMulti
                      />
                </FormGroup>
                </Col>
                </Row>

                <Row>
                <Col xs="8">
                <FormGroup>
                      <Label htmlFor="dobody">Body</Label>
                      <Input type="textarea" rows="5" onChange={this.handleChangeBody}
                             placeholder="Today plan some fun for the weekend. Book up somewhere, plan an outing, arrange a fun get-together with friends or family now. -- Doing something enjoyable helps you stay active and improves mood. Make sure you have fun activities scheduled regularly. --" />
                  </FormGroup>
                  </Col>
                  <Col xs="4">
                    <FormGroup>
                      <Label htmlFor="typedo">Type of Do</Label>
                      <Select
                        value={selectedDoType}
                        onChange={this.handleChangeType}
                        options={TypesofDos}
                        />

                    </FormGroup>

                    <FormGroup>
                      <Label htmlFor="difficulty">Difficulty</Label>
                      <Input type="select" name="difficulty" id="difficulty">
                        <option value="any">Any</option>
                        <option value="simple">Simple</option>
                        <option value="average">Average</option>
                        <option value="hard">Hard</option>
                      </Input>
                    </FormGroup>
                  </Col>
                </Row>
                  
              </CardBody>

              <CardFooter>

                <Button type="submit" color="primary"><i className="fa fa-dot-circle-o" onClick={this.handleSubmit} ></i> Submit</Button>
                <Button type="reset" color="secondary"><i className="fa fa-ban" ></i> Reset</Button>

              </CardFooter>
             
              </Form>

            </Card>
          </Col>

    );
  }
}

export default SearchForm;
