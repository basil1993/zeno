import React, { Component } from 'react';
import { Card, CardHeader, CardBody, Row, Col } from 'reactstrap';
import Select from 'react-select';

import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit'

import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import 'react-bootstrap-table2-toolkit/dist/react-bootstrap-table2-toolkit.min.css'

import Dodata from "./data/Preventomics_Meteda_Aldi.json";


// this function checks the value of the cell, if it says avs in JSON it shows data-driven in the cell
function format(cell) {
  if (cell === "avs") {
    return "data-driven";
  }
  return (cell)
}

// var SelectedLanguage = null

// // define table columns and their properties
// var columns = [{
//   dataField: 'category',
//   text: 'Category',
//   formatter: format,
//   sort: true,
//   headerStyle: () => {
//     return { width: "15%" };
//   }
// },
// {
//   dataField: `title@${SelectedLanguage}`,
//   text: 'Title',
//   sort: true,
//   headerStyle: () => {
//     return { width: "20%" };
//   }
// },
// {
//   dataField: `body@${SelectedLanguage}`,
//   text: 'Body',
//   sort: true,
//   style: {
//   }
// },
// {
//   dataField: `question@${SelectedLanguage}`,
//   text: 'Question',
//   sort: true
// }
// ];

//define searchbar and clear button
const { SearchBar, ClearSearchButton } = Search

// define list of available languages
const languages = [
  { value: 'en', label: 'English' },
  { value: 'pl', label: 'Polish' },
  { value: 'da', label: 'Danish' },
  { value: 'es', label: 'Spanish' },
  { value: 'ca', label: 'Catalan' },
];

class DoTable extends Component {

  // deal with language selection 
  constructor(props) {
    super(props);
    this.state = {
      SelectedLanguage: languages[0],

      columns: [{
        dataField: 'category',
        text: 'Category',
        formatter: format,
        sort: true,
        headerStyle: () => {
          return { width: "15%" };
        }
      },
      {
        dataField: `title@en`,
        text: 'Title',
        sort: true,
        headerStyle: () => {
          return { width: "20%" };
        }
      },
      {
        dataField: `body@en`,
        text: 'Body',
        sort: true,
        style: {
        }
      },
      {
        dataField: `question@en`,
        text: 'Question',
        sort: true
      }
      ],
    };
  }

  // handle language selection and update the state
  handleChangeLanguage = SelectedLanguage => {

    //update selectedlanguage and the datafield in columns
    this.setState({
      SelectedLanguage, columns: [{
        dataField: 'category',
        text: 'Category',
        formatter: format,
        sort: true,
        headerStyle: () => {
          return { width: "15%" };
        }
      },
      {
        dataField: `title@${SelectedLanguage.value}`,
        text: 'Title',
        sort: true,
        headerStyle: () => {
          return { width: "20%" };
        }
      },
      {
        dataField: `body@${SelectedLanguage.value}`,
        text: 'Body',
        sort: true,
        style: {
        }
      },
      {
        dataField: `question@${SelectedLanguage.value}`,
        text: 'Question',
        sort: true
      }]
    })
  };

  render() {

    // let the language selector set a language in state
    var { SelectedLanguage } = this.state;
    // console.log(`Language selected:`, SelectedLanguage);

    return (

      <Card>

        <ToolkitProvider
          keyField="body@en"
          data={Dodata}
          columns={this.state.columns}
          search={{ searchFormatted: true }}
        >

          {
            props => (
              <div>

                <CardHeader>
                  <Row>
                    <Col sm="3">
                      <i className="icon-speech">{' '}</i><strong>Do Repository</strong>{' '}
                      <div className="small text-muted">Search title, body, etc</div>
                    </Col>
                    <Col sm="3"></Col>
                    <Col sm="1">
                      <ClearSearchButton className="btn First-btn float-right" {...props.searchProps} />
                    </Col>
                    <Col sm="3">
                      <SearchBar className="float-right" placeholder="Search" {...props.searchProps} />
                    </Col>
                    <Col sm="2">

                      <Select
                        value={SelectedLanguage}
                        onChange={this.handleChangeLanguage}
                        options={languages}
                        theme={theme => ({
                          ...theme,
                          colors: {
                            ...theme.colors,
                            // primary25: '#EF7B0B',
                            primary: '#EF7B0B',
                          },
                        })}
                      />

                    </Col>
                  </Row>

                </CardHeader>

                <CardBody>
                  <BootstrapTable
                    {...props.baseProps}
                    keyField='body@en'
                    data={Dodata}
                    columns={this.state.columns}
                    hover
                    bordered={false}
                    noDataIndication="No Do's available"
                    pagination={paginationFactory()}
                    striped
                    bootstrap4

                  />

                </CardBody>

              </div>
            )
          }
        </ToolkitProvider>

      </Card>

    );
  }
}


export default DoTable;

// add this to the css file for long text
// .doTable{
//   white-space: nowrap;
//   text-overflow: ellipsis;
//   overflow: hidden;
// }