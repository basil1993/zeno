import React from 'react';
import { Card, CardBody, Button, Col, Container, Row } from 'reactstrap';
import { Link } from "react-router-dom";

import Lottie from 'react-lottie';
import fingerprint from './lotties/fingerprint_Preventomics.json';

// import { useAuth0 } from "./utils/react-auth0-spa";

const Welcome = () => {

  //lottie settings
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: fingerprint,
    rendererSettings: {
      preserveAspectRatio: 'xMidYMid slice'
    }
  };

  return (

    
    <div className="animated fadeIn app flex-row align-items-center">

      <Container>
        <Row className="justify-content-center">
          <Col xs="8" sm="6" lg="4">
            <Card className="text-black bg-light">
              <CardBody className="text-center">
                <div>

                  <Lottie options={defaultOptions}
                    height={60}
                    width={60}
                  />

                  <h1>Zeno</h1>
                  <p>Please use your Auth0 account to login. If you don't have an account yet, contact Onmi to set one up.</p>

                  <Row className="justify-content-center">

                    <Link to="/dashboard" className="btn First-btn">Login </Link>
                    <Button outline color="dark" href="mailto:info@onmi.design?subject=Zeno access request">Contact</Button>
                    {/* <Button outline color="primary" onClick={IwantaToken}>get Token</Button> */}

                  </Row>

                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
        
      </Container>
    </div>
  );
}

export default Welcome;