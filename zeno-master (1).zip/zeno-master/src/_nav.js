export default {
  items: [
    {
      name: 'Dashboard',
      url: '/dashboard',
      icon: 'icon-speedometer',
    },
    {
      title: true,
      name: "Do's",
      wrapper: {            // optional wrapper object
        element: '',        // required valid HTML5 element tag
        attributes: {}        // optional valid JS object with JS API naming ex: { className: "my-class", style: { fontFamily: "Verdana" }, id: "my-id"}
      }
    },
    {
      name: 'Overview',
      url: '/Do/overview',
      icon: 'icon-trophy',
    },
    {
      name: 'Repository',
      url: '/Do/repository',
      icon: 'icon-speech',
    },
    {
      title: true,
      name: 'Programme',
      wrapper: {            // optional wrapper object
        element: '',        // required valid HTML5 element tag
        attributes: {}        // optional valid JS object with JS API naming ex: { className: "my-class", style: { fontFamily: "Verdana" }, id: "my-id"}
      }
    },
    {
      name: 'Users',
      url: '/Programme/users',
      icon: 'icon-people',
    },
    {
      name: 'Schedule',
      url: '/Programme/schedule',
      icon: 'icon-calendar',
    },
    {
      name: 'Intake',
      url: '/Programme/intake',
      icon: 'icon-doc',
      badge: {
        variant: 'info',
        text: 'SOON..',
      },
    },
    {
      title: true,
      name: 'Input',
      wrapper: {            // optional wrapper object
        element: '',        // required valid HTML5 element tag
        attributes: {}        // optional valid JS object with JS API naming ex: { className: "my-class", style: { fontFamily: "Verdana" }, id: "my-id"}
      }
    },
    {
      name: 'Typeform',
      url: '/input',
      icon: 'icon-docs',
      badge: {
        variant: 'info',
        text: 'SOON..',
      },
    }
  ]
};
