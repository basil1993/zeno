import React from 'react';
import DefaultLayout from './containers/DefaultLayout';

const Dashboard = React.lazy(() => import('./views/Dashboard'));
const Repository = React.lazy(() => import('./views/Do/Repository'));
const Overview = React.lazy(() => import('./views/Do/Overview'));
const Programme_Intake = React.lazy(() => import('./views/Programme/Intake/Programme_Intake'));
const Programme_Users = React.lazy(() => import('./views/Programme/Users/Programme_Users'));
const Programme_Schedule = React.lazy(() => import('./views/Programme/Schedule/Programme_Schedule'));
const Typeform = React.lazy(() => import('./views/Input/Typeform'));

// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  
  { path: '/', name: 'Home', component: DefaultLayout, exact: true },
  { path: '/dashboard', name: 'Dashboard', component: Dashboard },
  { path: '/do/repository', name: 'Repository', component: Repository },
  { path: '/do/overview', name: 'Overview', component: Overview },
  { path: '/programme/intake', name: 'Intake', component: Programme_Intake },
  { path: '/programme/users', name: 'Users', component: Programme_Users },
  { path: '/programme/schedule', name: 'Schedule', component: Programme_Schedule },
  { path: '/input', name: 'Typeform', component: Typeform },

];

export default routes;
